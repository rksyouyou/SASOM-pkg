varfun <- function(mu){
  ## construct variance matrix for multionmial response
  mu.s <- as.vector(mu)
  n <- nrow(mu)
  s.J <- ncol(mu)
  D <- matrix(0,n*s.J,n*s.J)
  for(i in 1:(s.J-1))
    for(j in (i+1):s.J)
      diag(D[(n*(i-1)+1):(n*i),(n*(j-1)+1):(n*j)]) <- -mu[,i]*mu[,j]
  D <- D+t(D)
  diag(D)  <- mu.s*(1-mu.s)
  return(D)
}
