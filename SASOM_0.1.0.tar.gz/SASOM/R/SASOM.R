

SASOM <- function(y,X,G,W,p.comb = c("all","DAPC","fisher","tippet")){

    ## check the format of Y, if its a vector, convert it to matrix
    if(is.vector(y)|is.factor(y)) {
        y <- as.factor(y)
        J <- length(levels(y))
        n <- length(y)
        ymat <- matrix(0,n,J)
        ymat[cbind(1:n,as.numeric(y))] <- 1
        colnames(ymat) <- levels(y)
    } else if(is.matrix(y)) {
        if(any(rowSums(y)!=1)) stop("Error: summation of each row must equal to 1!")
        J <- ncol(y)
        n <- nrow(y)
        ymat <- y
        colnames(ymat) <- 1:J
    } else {
        stop("Error: y must be a vector or matrix!")
    }

    ## check if there is intercept in X, if not add intercept column
    if(sum(X[,1] == 1)<n){
        print('An intercept column is added to covariant matrix.')
        X <- cbind(1,X)
    }

    ## check dimension of input matrices
    if(nrow(X)!=n) stop('Error: dimensions of covariant matrix and response are inconsistent!')
    if(nrow(G)!=n) stop('Error: dimensions of variant matrix and response are inconsistent!')
    if(ncol(G)!=ncol(W)) stop('Error: dimensions of variant and variant character matrices are inconsistent!')

    ## define new notations for futurn use
    p = ncol(G)
    q <- nrow(W)
    Gw <- G%*%t(W)
    Y.s <- matrix(as.vector(ymat[,-1]),ncol=1)
    X.s <- kronecker(diag(J-1),X)
    G.s <- kronecker(diag(J-1),G)
    S <- kronecker(diag(J-1),t(Gw))
    M <- cbind(X,Gw)
    M.s <- kronecker(diag(J-1),M)

    ## fit two models under H01 and H02
    fit1 <- multinom(ymat~0+X,trace=FALSE)
    fit2 <- multinom(ymat~0+X+Gw,trace=FALSE)
    mu1 <- fit1$fitted.values[,-1]
    mu2 <- fit2$fitted.values[,-1]
    mu1.s <- as.vector(mu1)
    mu2.s <- as.vector(mu2)

    ## construct variance matrix under H01 and H02
    D1 <- varfun(mu1)
    D2 <- varfun(mu2)

    ## score test for theta
    U.theta <- S%*%(Y.s-mu1.s) # (J-1)q*1
    DX <- D1%*%X.s
    V.theta <- S%*%(D1-DX%*%solve(t(X.s)%*%DX)%*%t(DX))%*%t(S)
    stat.theta <- t(U.theta)%*%solve(V.theta)%*%(U.theta)
    pval.theta <- pchisq(stat.theta,(J-1)*q,lower.tail=FALSE)

    ## score test for tau
    A = rbind(kronecker(diag(J-1),diag(p)),kronecker(matrix(1,ncol=J-1,nrow=1),diag(p)))
    U.tau <- A%*%t(G.s)%*%(Y.s-mu2.s)
    DM <- D2%*%M.s
    V.tau = NULL
    V.tau <- A%*%t(G.s)%*%(D2-DM%*%solve(t(M.s)%*%DM)%*%t(DM))%*%G.s%*%t(A)
    stat.tau <- sum(U.tau^2)
    lam <- eigen(V.tau,symmetric=TRUE)$values
    pval.tau <- davies(stat.tau, lam,lim=5000,acc=1e-04)$Qq
    if(pval.tau<=0) pval.tau  = liu(stat.tau,lam)

    ## overall p-value
    if(p.comb == "all"|is.null(p.comb)){
      pval.fisher <-  fisher(c(pval.theta,pval.tau))
      pval.tippet <-  tippet(c(pval.theta,pval.tau))
      pval.dapc <-  DAPC(c(pval.theta,pval.tau))
      out <- c(pval.theta=pval.theta,pval.tau=pval.tau,p.fisher=pval.fisher,p.tippet=pval.tippet,p.dapc=pval.dapc)
    }
    if(p.comb == "DAPC"){
      pval.dapc <-  DAPC(c(pval.theta,pval.tau))
      out <- c(pval.theta=pval.theta,pval.tau=pval.tau,p.dapc=pval.dapc)
    }
    if(p.comb == "fisher"){
      pval.fisher <-  fisher(c(pval.theta,pval.tau))
      out <- c(pval.theta=pval.theta,pval.tau=pval.tau,p.fisher=pval.fisher)
    }
    if(p.comb == "tippet"){
      pval.tippet <-  tippet(c(pval.theta,pval.tau))
      out <- c(pval.theta=pval.theta,pval.tau=pval.tau,p.tippet=pval.tippet)
    }


    return(out)
}



